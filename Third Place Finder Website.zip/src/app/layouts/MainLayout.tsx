import { Header } from '../components/Header';
import { ChatBox } from '../components/ChatBox';
import { MapWindow } from '../components/MapWindow';
import { AudioMixer } from '../components/AudioMixer';
import { PomodoroTimer } from '../components/PomodoroTimer';

export function MainLayout() {
  return (
    <div className="h-screen w-full flex flex-col overflow-hidden bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-950">
      {/* Header */}
      <Header />

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Column - Chat */}
        <div className="w-80 flex-shrink-0 border-r border-slate-200/50 dark:border-slate-700/50">
          <ChatBox />
        </div>

        {/* Middle Column - Map */}
        <div className="flex-1">
          <MapWindow />
        </div>

        {/* Right Column - Audio Mixer & Timer */}
        <div className="w-80 flex-shrink-0 flex flex-col overflow-hidden border-l border-slate-200/50 dark:border-slate-700/50">
          <div className="flex-shrink-0">
            <AudioMixer />
          </div>
          <div className="flex-1 overflow-auto">
            <PomodoroTimer />
          </div>
        </div>
      </div>
    </div>
  );
}
