import { useState } from 'react';
import { MapPin, Coffee, BookOpen, TreePine, Book, Palette, Heart, Star, Clock, Navigation, Search, Filter, X } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Input } from './ui/input';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';

interface ThirdPlace {
  id: number;
  name: string;
  lat: number;
  lng: number;
  type: string;
  icon: any;
  distance: string;
  rating: number;
  status: 'open' | 'closing-soon' | 'closed';
  closingTime?: string;
  address: string;
  reviews: number;
  imageUrl: string;
  description: string;
}

const thirdPlaces: ThirdPlace[] = [
  { 
    id: 1, 
    name: 'Cozy Coffee Shop', 
    lat: 40.7589, 
    lng: -73.9851, 
    type: 'Cafe', 
    icon: Coffee,
    distance: '0.3 mi',
    rating: 4.8,
    status: 'open',
    closingTime: '9:00 PM',
    address: '123 Main St, New York, NY',
    reviews: 342,
    imageUrl: 'https://images.unsplash.com/photo-1642315160505-b3dff3a3c8b9?w=400',
    description: 'Perfect spot for remote work with great coffee and cozy atmosphere.'
  },
  { 
    id: 2, 
    name: 'Community Library', 
    lat: 40.7614, 
    lng: -73.9776, 
    type: 'Library', 
    icon: BookOpen,
    distance: '0.5 mi',
    rating: 4.6,
    status: 'open',
    closingTime: '8:00 PM',
    address: '456 Park Ave, New York, NY',
    reviews: 198,
    imageUrl: 'https://images.unsplash.com/photo-1507842217343-583bb7270b66?w=400',
    description: 'Quiet reading rooms and excellent study spaces available.'
  },
  { 
    id: 3, 
    name: 'Central Park', 
    lat: 40.7829, 
    lng: -73.9654, 
    type: 'Park', 
    icon: TreePine,
    distance: '1.2 mi',
    rating: 4.9,
    status: 'open',
    address: 'Central Park, New York, NY',
    reviews: 5432,
    imageUrl: 'https://images.unsplash.com/photo-1568515387631-8b650bbcdb90?w=400',
    description: 'Beautiful green space for outdoor work and relaxation.'
  },
  { 
    id: 4, 
    name: 'Local Bookstore', 
    lat: 40.7489, 
    lng: -73.9680, 
    type: 'Bookstore', 
    icon: Book,
    distance: '0.8 mi',
    rating: 4.5,
    status: 'closing-soon',
    closingTime: '6:00 PM',
    address: '789 Broadway, New York, NY',
    reviews: 267,
    imageUrl: 'https://images.unsplash.com/photo-1495446815901-a7297e633e8d?w=400',
    description: 'Independent bookstore with reading nooks and local author events.'
  },
  { 
    id: 5, 
    name: 'Art Gallery', 
    lat: 40.7505, 
    lng: -73.9934, 
    type: 'Gallery', 
    icon: Palette,
    distance: '1.5 mi',
    rating: 4.7,
    status: 'closed',
    closingTime: 'Opens 10:00 AM',
    address: '321 Gallery Row, New York, NY',
    reviews: 156,
    imageUrl: 'https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?w=400',
    description: 'Contemporary art space with inspiring exhibitions and cafe.'
  },
];

export function MapWindow() {
  const [selectedPlace, setSelectedPlace] = useState<number | null>(null);
  const [hoveredPlace, setHoveredPlace] = useState<number | null>(null);
  const [favorites, setFavorites] = useState<Set<number>>(new Set([1, 3]));
  const [searchQuery, setSearchQuery] = useState('');
  const [showOnlyFavorites, setShowOnlyFavorites] = useState(false);
  const [selectedTypes, setSelectedTypes] = useState<string[]>(['Cafe', 'Library', 'Park', 'Bookstore', 'Gallery']);
  const [showCurrentLocation, setShowCurrentLocation] = useState(false);

  const toggleFavorite = (id: number) => {
    const newFavorites = new Set(favorites);
    if (newFavorites.has(id)) {
      newFavorites.delete(id);
    } else {
      newFavorites.add(id);
    }
    setFavorites(newFavorites);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'text-green-600 bg-green-50 dark:bg-green-900/20 dark:text-green-400';
      case 'closing-soon': return 'text-orange-600 bg-orange-50 dark:bg-orange-900/20 dark:text-orange-400';
      case 'closed': return 'text-red-600 bg-red-50 dark:bg-red-900/20 dark:text-red-400';
      default: return 'text-slate-600 bg-slate-50';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'open': return 'Open';
      case 'closing-soon': return 'Closing Soon';
      case 'closed': return 'Closed';
      default: return 'Unknown';
    }
  };

  const toggleTypeFilter = (type: string) => {
    setSelectedTypes(prev => 
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };

  const filteredPlaces = thirdPlaces.filter(place => {
    const matchesSearch = place.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         place.type.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFavorites = !showOnlyFavorites || favorites.has(place.id);
    const matchesType = selectedTypes.includes(place.type);
    return matchesSearch && matchesFavorites && matchesType;
  });

  const hoveredPlaceData = hoveredPlace ? thirdPlaces.find(p => p.id === hoveredPlace) : null;

  return (
    <div className="h-full w-full relative bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-900 dark:to-slate-950">
      {/* Interactive Map */}
      <div className="w-full h-full relative">
        <iframe
          width="100%"
          height="100%"
          frameBorder="0"
          scrolling="no"
          marginHeight={0}
          marginWidth={0}
          src="https://www.openstreetmap.org/export/embed.html?bbox=-74.0259%2C40.7089%2C-73.9443%2C40.7789&layer=mapnik&marker=40.7589%2C-73.9851"
          style={{ border: 0, filter: 'grayscale(20%) brightness(95%)' }}
          className="dark:brightness-75 dark:contrast-125 dark:invert dark:hue-rotate-180"
        />
        
        {/* Current Location Toggle */}
        <Button
          onClick={() => setShowCurrentLocation(!showCurrentLocation)}
          className={`absolute top-4 right-4 z-20 shadow-xl ${
            showCurrentLocation 
              ? 'bg-violet-500 hover:bg-violet-600 text-white' 
              : 'bg-white/90 dark:bg-slate-800/90 hover:bg-white dark:hover:bg-slate-800 text-slate-900 dark:text-slate-100'
          } backdrop-blur-xl border border-slate-200 dark:border-slate-700`}
          size="icon"
        >
          <Navigation className={`h-4 w-4 ${showCurrentLocation ? 'fill-current' : ''}`} />
        </Button>
      </div>

      {/* Detail Card on Hover */}
      {hoveredPlaceData && (
        <div 
          className="absolute top-4 left-4 z-30 w-80 bg-white/95 dark:bg-slate-800/95 backdrop-blur-xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 overflow-hidden animate-in fade-in slide-in-from-left-2 duration-300"
        >
          <div className="relative h-40 overflow-hidden">
            <ImageWithFallback
              src={hoveredPlaceData.imageUrl}
              alt={hoveredPlaceData.name}
              className="w-full h-full object-cover"
            />
            <button
              onClick={() => setHoveredPlace(null)}
              className="absolute top-2 right-2 p-1.5 bg-black/50 hover:bg-black/70 rounded-lg transition-colors"
            >
              <X className="h-4 w-4 text-white" />
            </button>
          </div>
          
          <div className="p-4 space-y-3">
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1">
                <h3 className="font-semibold text-slate-900 dark:text-slate-100 tracking-tight">
                  {hoveredPlaceData.name}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                  {hoveredPlaceData.address}
                </p>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  toggleFavorite(hoveredPlaceData.id);
                }}
                className="flex-shrink-0 p-2 hover:scale-110 transition-transform"
              >
                <Heart 
                  className={`h-5 w-5 ${
                    favorites.has(hoveredPlaceData.id)
                      ? 'fill-red-500 text-red-500' 
                      : 'text-slate-400 hover:text-red-400'
                  }`}
                />
              </button>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-400">
              {hoveredPlaceData.description}
            </p>

            <div className="flex items-center gap-2 flex-wrap">
              <div className="flex items-center gap-1 px-2 py-1 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                <Star className="h-3.5 w-3.5 fill-yellow-500 text-yellow-500" />
                <span className="text-xs font-semibold text-yellow-700 dark:text-yellow-400">
                  {hoveredPlaceData.rating}
                </span>
                <span className="text-xs text-slate-500 dark:text-slate-400">
                  ({hoveredPlaceData.reviews})
                </span>
              </div>
              
              <div className={`flex items-center gap-1 px-2 py-1 rounded-lg ${getStatusColor(hoveredPlaceData.status)}`}>
                <Clock className="h-3.5 w-3.5" />
                <span className="text-xs font-medium">
                  {getStatusText(hoveredPlaceData.status)}
                </span>
              </div>

              <div className="flex items-center gap-1 px-2 py-1 bg-blue-50 dark:bg-blue-900/20 rounded-lg text-blue-600 dark:text-blue-400">
                <MapPin className="h-3.5 w-3.5" />
                <span className="text-xs font-medium">
                  {hoveredPlaceData.distance}
                </span>
              </div>
            </div>

            {hoveredPlaceData.closingTime && (
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {hoveredPlaceData.closingTime}
              </p>
            )}
          </div>
        </div>
      )}

      {/* Search & Filter Bar */}
      <div className="absolute top-4 left-4 right-4 z-10 flex gap-2">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input
            placeholder="Search places..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-white/95 dark:bg-slate-800/95 backdrop-blur-xl border-slate-200 dark:border-slate-700 shadow-xl"
          />
        </div>
        
        <DropdownMenu>
          <DropdownMenuTrigger className="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 h-9 px-4 py-2 bg-white/95 dark:bg-slate-800/95 hover:bg-white dark:hover:bg-slate-800 text-slate-900 dark:text-slate-100 backdrop-blur-xl border border-slate-200 dark:border-slate-700 shadow-xl">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56 bg-white/95 dark:bg-slate-800/95 backdrop-blur-xl border-slate-200 dark:border-slate-700">
            <DropdownMenuCheckboxItem
              checked={showOnlyFavorites}
              onCheckedChange={setShowOnlyFavorites}
            >
              <Heart className="h-4 w-4 mr-2" />
              Show Favorites Only
            </DropdownMenuCheckboxItem>
            {['Cafe', 'Library', 'Park', 'Bookstore', 'Gallery'].map(type => (
              <DropdownMenuCheckboxItem
                key={type}
                checked={selectedTypes.includes(type)}
                onCheckedChange={() => toggleTypeFilter(type)}
              >
                {type}
              </DropdownMenuCheckboxItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Places List */}
      <div className="absolute bottom-4 left-4 right-4 z-10 bg-white/95 dark:bg-slate-800/95 backdrop-blur-xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 max-h-64 overflow-hidden">
        <div className="p-4 border-b border-slate-200/50 dark:border-slate-700/50 bg-gradient-to-r from-violet-50/50 to-blue-50/50 dark:from-violet-900/20 dark:to-blue-900/20">
          <h3 className="font-semibold flex items-center gap-2 text-slate-900 dark:text-slate-100 tracking-tight">
            <MapPin className="h-4 w-4 text-violet-600 dark:text-violet-400" />
            Nearby Third Places
            <span className="text-xs font-normal text-slate-500 dark:text-slate-400">
              ({filteredPlaces.length})
            </span>
          </h3>
        </div>
        
        <div className="overflow-auto max-h-48 p-2">
          <div className="space-y-2">
            {filteredPlaces.map((place) => {
              const Icon = place.icon;
              const isFavorite = favorites.has(place.id);
              
              return (
                <div
                  key={place.id}
                  onClick={() => setSelectedPlace(place.id)}
                  onMouseEnter={() => setHoveredPlace(place.id)}
                  onMouseLeave={() => setHoveredPlace(null)}
                  className={`w-full text-left p-3 rounded-xl border transition-all group hover:scale-[1.02] cursor-pointer ${
                    selectedPlace === place.id
                      ? 'bg-gradient-to-r from-violet-50 to-blue-50 dark:from-violet-900/30 dark:to-blue-900/30 border-violet-300 dark:border-violet-700 shadow-lg'
                      : 'bg-white/60 dark:bg-slate-700/60 border-slate-200/50 dark:border-slate-600/50 hover:bg-white/80 dark:hover:bg-slate-700/80 hover:shadow-md'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`flex-shrink-0 w-10 h-10 rounded-lg bg-gradient-to-br from-violet-100 to-blue-100 dark:from-violet-900/40 dark:to-blue-900/40 flex items-center justify-center transition-transform group-hover:scale-110 ${
                      selectedPlace === place.id ? 'scale-110' : ''
                    }`}>
                      <Icon className="h-5 w-5 text-violet-600 dark:text-violet-400" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <h4 className="font-semibold text-sm truncate text-slate-900 dark:text-slate-100 tracking-tight">
                          {place.name}
                        </h4>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleFavorite(place.id);
                          }}
                          className="flex-shrink-0 p-1 hover:scale-125 transition-transform"
                        >
                          <Heart 
                            className={`h-4 w-4 transition-colors ${
                              isFavorite 
                                ? 'fill-red-500 text-red-500' 
                                : 'text-slate-400 hover:text-red-400'
                            }`}
                          />
                        </button>
                      </div>
                      
                      <div className="flex items-center gap-3 mb-2 text-xs">
                        <span className="text-slate-600 dark:text-slate-400">{place.type}</span>
                        <span className="text-slate-400 dark:text-slate-500">•</span>
                        <span className="text-slate-600 dark:text-slate-400 font-medium">{place.distance}</span>
                      </div>
                      
                      <div className="flex items-center gap-2 flex-wrap">
                        <div className="flex items-center gap-1 px-2 py-0.5 bg-yellow-50 dark:bg-yellow-900/20 rounded-full">
                          <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                          <span className="text-xs font-semibold text-yellow-700 dark:text-yellow-400">
                            {place.rating}
                          </span>
                        </div>
                        
                        <div className={`flex items-center gap-1 px-2 py-0.5 rounded-full ${getStatusColor(place.status)}`}>
                          <Clock className="h-3 w-3" />
                          <span className="text-xs font-medium">
                            {getStatusText(place.status)}
                          </span>
                        </div>
                        
                        {place.closingTime && (
                          <span className="text-[10px] text-slate-500 dark:text-slate-400">
                            {place.closingTime}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}