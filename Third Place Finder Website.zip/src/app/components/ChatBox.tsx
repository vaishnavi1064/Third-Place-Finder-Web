import { useState } from 'react';
import { Send, RefreshCw } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';

interface Message {
  id: string;
  text: string;
  sender: string;
  timestamp: Date;
}

export function ChatBox() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Welcome to Third Place Finder! Share your favorite spots.',
      sender: 'System',
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');

  const handleSend = () => {
    if (inputValue.trim()) {
      const newMessage: Message = {
        id: Date.now().toString(),
        text: inputValue,
        sender: 'You',
        timestamp: new Date(),
      };
      setMessages([...messages, newMessage]);
      setInputValue('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  const handleRefresh = () => {
    setMessages([
      {
        id: '1',
        text: 'Welcome to Third Place Finder! Share your favorite spots.',
        sender: 'System',
        timestamp: new Date(),
      },
    ]);
    setInputValue('');
  };

  return (
    <div className="h-full flex flex-col bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl">
      <div className="p-4 border-b border-slate-200/50 dark:border-slate-700/50 bg-gradient-to-r from-violet-50/50 to-blue-50/50 dark:from-violet-900/20 dark:to-blue-900/20 flex items-center justify-between">
        <h2 className="font-semibold text-slate-900 dark:text-slate-100 tracking-tight">Community Chat</h2>
        <Button
          onClick={handleRefresh}
          variant="ghost"
          size="sm"
          className="hover:bg-white/60 dark:hover:bg-slate-800/60"
          title="Refresh chat"
        >
          <RefreshCw className="h-4 w-4 text-slate-600 dark:text-slate-400" />
        </Button>
      </div>
      
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <div 
              key={message.id} 
              className="space-y-1"
            >
              <div className="flex items-baseline gap-2">
                <span className="font-medium text-sm text-slate-900 dark:text-slate-100 tracking-tight">{message.sender}</span>
                <span className="text-xs text-slate-500 dark:text-slate-400">
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
              <div className="bg-white/60 dark:bg-slate-800/60 backdrop-blur-sm p-3 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-all">
                <p className="text-sm text-slate-700 dark:text-slate-300">{message.text}</p>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>

      <div className="p-4 border-t border-slate-200/50 dark:border-slate-700/50 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md">
        <div className="flex gap-2">
          <Input
            type="text"
            placeholder="Type a message..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            className="bg-white/60 dark:bg-slate-900/60 backdrop-blur-sm border-slate-200 dark:border-slate-700"
          />
          <Button 
            onClick={handleSend} 
            size="icon"
            className="bg-gradient-to-r from-violet-500 to-blue-500 hover:from-violet-600 hover:to-blue-600 transition-all hover:scale-110"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
